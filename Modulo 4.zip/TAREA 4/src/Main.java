/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Keren Serrano
 */
public class Main {
    public static void main(String[] args) {
        
        GestorEmpleado gestor = new GestorEmpleado( );

       
        Empleado emp1 = new Empleado("Juan", 30, 2500.0);
        Empleado emp2 = new Empleado("María", 28, 2800.0);

        gestor.agregarEmpleado(emp1);
        gestor.agregarEmpleado(emp2);

        
        System.out.println("Detalles de empleados:");
        gestor.mostrarEmpleados();
    }
}

