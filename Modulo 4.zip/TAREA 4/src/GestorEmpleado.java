/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Keren Serrano
 */

    import java.util.ArrayList;
import java.util.List;

public class GestorEmpleado {
    private List<Empleado> listaEmpleados;

   
    public GestorEmpleado () {
        listaEmpleados = new ArrayList<>();
    }

    
    public void agregarEmpleado(Empleado empleado) {
        listaEmpleados.add(empleado);
    }


    public void mostrarEmpleados() {
        for (Empleado empleado : listaEmpleados) {
            empleado.imprimirInformacion ();
        }
    }

   
}
    

