/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Keren Serrano
 */
public class gastoEmpleados {
    public class Main {
    public static void main(String[] args) {
        gastoEmpleados gestor = new gastoEmpleados();

        gestor.agregarEmpleado(emp2);
       
        Empleado emp1 = new Empleado("Juan", 30, 2500.0);
        Empleado emp2 = new Empleado("María", 28, 2800.0);

        gestor.agregarEmpleado(emp1);

        // Mostrar detalles de los empleados
        System.out.println("Detalles de empleados:");
        gestor.mostrarEmpleados();
    }
}
    
}
