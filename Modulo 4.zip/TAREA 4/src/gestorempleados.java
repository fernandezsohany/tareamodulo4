/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Keren Serrano
 */
public class gestorempleados {
    import java.util.ArrayList;
import java.util.List;

public class GestorEmpleados {
    private List<Empleado> listaEmpleados;

    // Constructor
    public GestorEmpleados() {
        listaEmpleados = new ArrayList<>();
    }

    // Método para agregar un empleado a la lista
    public void agregarEmpleado(Empleado empleado) {
        listaEmpleados.add(empleado);
    }

    // Método para mostrar los detalles de todos los empleados
    public void mostrarEmpleados() {
        for (Empleado empleado : listaEmpleados) {
            empleado.imprimirInformacion();
        }
    }

    // Otros métodos según necesidades adicionales (eliminar, buscar, etc.)
}
    
}
